function [ myrotateIM ] = myrotate( image )
%rotate 90 degrees clockwise
theta = pi/2;



rmat = [
cos(theta) sin(theta) 0
-sin(theta) cos(theta) 0
0           0          1];

mx = size(image,2);
my = size(image,1);
corners = [
    0  0  1
    mx 0  1
    0  my 1
    mx my 1];


new_c = corners*rmat;

% transform matrix
T = maketform('affine', rmat);  

myrotateIM = imtransform(image, T, ...
    'XData',[min(new_c(:,1)) max(new_c(:,1))],...
    'YData',[min(new_c(:,2)) max(new_c(:,2))]);



end

